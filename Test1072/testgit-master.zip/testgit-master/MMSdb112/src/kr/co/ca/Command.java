package kr.co.ca;

import java.util.Scanner;

public interface Command {
	
	public abstract void execute(Scanner sc);
	
}
